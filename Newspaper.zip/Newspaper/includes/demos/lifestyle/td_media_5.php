<?php

// ads

td_demo_media::add_image_to_media_gallery('td_lifestyle_ad',                      "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/reclama-lifestyle.jpg");
td_demo_media::add_image_to_media_gallery('td_lifestyle_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/300x250.jpg");
td_demo_media::add_image_to_media_gallery('td_lifestyle_custom_ad',              "http://demo_content.tagdiv.com/Newspaper_6/lifestyle/300x600.jpg");
