<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/gadgets/logo-header.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/gadgets/logo-other.png");
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_6/gadgets/logo-other.png");


// other images
td_demo_media::add_image_to_media_gallery('td_gadgets_footer_bg',       "http://demo_content.tagdiv.com/Newspaper_6/gadgets/12.jpg");