<?php

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_5',                   "http://demo_content.tagdiv.com/Newspaper_6/retro/5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_6',                   "http://demo_content.tagdiv.com/Newspaper_6/retro/6.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newspaper_6/retro/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newspaper_6/retro/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/retro/9.jpg");