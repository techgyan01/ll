<?php
//ads
td_demo_media::add_image_to_media_gallery('td_header_ad',              "http://demo_content.tagdiv.com/Newspaper_6/recipes/rec728.jpg");